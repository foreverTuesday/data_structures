
public class Stacker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayStack<Integer> as = new ArrayStack<Integer>(3);
		as.push(5);
		as.push(8);
		as.push(10);
		as.push(42);

		NodeStack<String> ns = new NodeStack<String>();
		ns.push("Hi");
		ns.push("hello");
		
	}

}
