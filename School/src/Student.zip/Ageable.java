
public interface Ageable {

	public Integer getAge();
	
}
