
public class Pkemon2 extends Pokemon1{

	Pkemon2(){
		super();
	}
	
	private String type2;
	
	
	public String getType2(){
		return type2;
		}

	public void setType2(String n){
		n= type2;
		}
	
}
